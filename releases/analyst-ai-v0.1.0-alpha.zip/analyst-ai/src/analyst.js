/**
 * @medina/analyst-ai — analyst.js
 *
 * AnalystAI — your embedded AI business analyst.
 *
 * Turn long reports, meeting notes, emails, and data dumps into
 * executive briefs, action items, and trend insights — without
 * sending your data anywhere.
 */

import {
  scoredSentences, keywords, findAnswer, similarity,
  extractNumbers, extractDates, readingStats, extractSections, sentences, words,
} from './_engine.js';

// Patterns that signal action items and decisions
const ACTION_SIGNALS = [
  /\b(action|task|to[-\s]?do|next step|follow[-\s]?up|assign|owner|responsible|deadline|due by|by [A-Z][a-z]+)\b/i,
  /\b(will|shall|must|need to|should|going to|plans? to|commit|agree)\b.*?\b(by|before|until|no later)\b/i,
  /\b(AI|team|group|everyone|[A-Z][a-z]+ [A-Z][a-z]+)\s+(will|shall|must|should|to)\b/i,
];

const DECISION_SIGNALS = [
  /\b(decided|agreed|approved|resolved|confirmed|signed off|concluded|voted|selected|chose|will proceed)\b/i,
  /\b(consensus|unanimous|approved by|green light|go ahead|moving forward)\b/i,
];

const RISK_SIGNALS = [
  /\b(risk|concern|issue|problem|blocker|obstacle|challenge|threat|vulnerability|gap|miss|fail|behind|delay|over budget)\b/i,
];

const OPPORTUNITY_SIGNALS = [
  /\b(opportunity|growth|potential|upside|advantage|gain|improve|increase|expand|accelerate|leverage|capitalize)\b/i,
];

export class AnalystAI {
  // ── Core Methods ───────────────────────────────────────────────────────────

  /**
   * Generate an executive brief from any document, report, or notes.
   *
   * Returns:
   *  - summary: the 3–5 most important sentences
   *  - keyMetrics: numbers and figures mentioned
   *  - decisions: sentences that describe decisions made
   *  - actions: action items extracted
   *  - risks: risk or issue mentions
   *  - opportunities: growth or opportunity mentions
   *  - stats: document stats
   *
   * @param {string} text
   * @param {object} [options]
   * @param {number} [options.summaryLength=4]
   * @returns {BriefResult}
   */
  brief(text, { summaryLength = 4 } = {}) {
    _need(text, 'brief');
    const top = scoredSentences(text).slice(0, summaryLength).map(s => s.sentence);
    const sents = sentences(text);

    return {
      summary: top.join(' '),
      keyMetrics: extractNumbers(text),
      keyDates: extractDates(text),
      decisions: sents.filter(s => DECISION_SIGNALS.some(p => p.test(s))).slice(0, 5),
      actions: sents.filter(s => ACTION_SIGNALS.some(p => p.test(s))).slice(0, 8),
      risks: sents.filter(s => RISK_SIGNALS.some(p => p.test(s))).slice(0, 5),
      opportunities: sents.filter(s => OPPORTUNITY_SIGNALS.some(p => p.test(s))).slice(0, 5),
      topKeywords: keywords(text, 8).map(k => k.word),
      stats: readingStats(text),
    };
  }

  /**
   * Extract specific types of information from a document.
   *
   * Types:
   *   'actions'      — action items and next steps
   *   'decisions'    — decisions that were made
   *   'risks'        — risks, blockers, concerns
   *   'numbers'      — all numeric values and metrics
   *   'dates'        — all dates and deadlines
   *   'sections'     — document section headings
   *   'keywords'     — top subject matter keywords
   *   'opportunities'— growth opportunities mentioned
   *
   * @param {string} text
   * @param {string} type
   * @returns {string[]|object[]}
   */
  extract(text, type) {
    _need(text, 'extract');
    const sents = sentences(text);
    switch (type.toLowerCase()) {
      case 'actions':      return sents.filter(s => ACTION_SIGNALS.some(p => p.test(s))).slice(0, 10);
      case 'decisions':    return sents.filter(s => DECISION_SIGNALS.some(p => p.test(s))).slice(0, 10);
      case 'risks':        return sents.filter(s => RISK_SIGNALS.some(p => p.test(s))).slice(0, 10);
      case 'numbers':      return extractNumbers(text);
      case 'dates':        return extractDates(text);
      case 'sections':     return extractSections(text).map(s => ({ heading: s.heading, preview: s.body.slice(0, 100) }));
      case 'keywords':     return keywords(text, 10).map(k => k.word);
      case 'opportunities':return sents.filter(s => OPPORTUNITY_SIGNALS.some(p => p.test(s))).slice(0, 10);
      default:
        throw new Error(`Unknown extract type "${type}". Use: actions, decisions, risks, numbers, dates, sections, keywords, opportunities`);
    }
  }

  /**
   * Ask a plain-language question about a document.
   * Returns the most relevant passage with confidence.
   *
   * @param {string} question
   * @param {string} context
   * @returns {{ answer: string|null, confidence: number, found: boolean }}
   */
  ask(question, context) {
    _need(question, 'ask (question)');
    _need(context, 'ask (context)');
    const { answer, confidence } = findAnswer(question, context);
    return {
      answer,
      confidence,
      found: !!answer && confidence > 0.1,
    };
  }

  /**
   * Find recurring themes across multiple documents (e.g. weekly reports).
   * Returns the keywords that appear most consistently across all texts.
   *
   * @param {string[]} texts — array of documents
   * @returns {{ themes: string[], frequency: object }}
   */
  trends(texts) {
    if (!Array.isArray(texts) || texts.length < 2) {
      throw new Error('AnalystAI.trends() requires an array of at least 2 texts.');
    }
    const allKw = texts.map(t => new Set(keywords(t, 15).map(k => k.word)));
    const freq = {};
    for (const kwSet of allKw) {
      for (const w of kwSet) freq[w] = (freq[w] || 0) + 1;
    }
    const themes = Object.entries(freq)
      .filter(([, count]) => count >= Math.ceil(texts.length * 0.5))
      .sort((a, b) => b[1] - a[1])
      .map(([word]) => word);
    return { themes, frequency: freq };
  }

  /**
   * Compare two documents or report versions.
   * Returns similarity, shared themes, and what changed.
   *
   * @param {string} docA
   * @param {string} docB
   * @returns {{ similarity: string, score: number, sharedThemes: string[], addedInB: string[], removedFromA: string[] }}
   */
  compare(docA, docB) {
    _need(docA, 'compare (docA)');
    _need(docB, 'compare (docB)');
    const { score, shared } = similarity(docA, docB);
    const kwA = keywords(docA, 12).map(k => k.word);
    const kwB = keywords(docB, 12).map(k => k.word);
    const setA = new Set(kwA), setB = new Set(kwB);
    return {
      similarity: `${Math.round(score * 100)}%`,
      score,
      sharedThemes: shared,
      addedInB: kwB.filter(w => !setA.has(w)).slice(0, 6),
      removedFromA: kwA.filter(w => !setB.has(w)).slice(0, 6),
    };
  }

  /**
   * Score a piece of writing against a set of criteria.
   * Each criterion is checked by keyword/phrase presence.
   * Returns a score (0–100) and which criteria passed.
   *
   * @param {string} text
   * @param {string[]} criteria — e.g. ['mentions ROI', 'includes timeline', 'has risk section']
   * @returns {{ score: number, passed: string[], failed: string[], grade: string }}
   */
  score(text, criteria) {
    _need(text, 'score');
    if (!Array.isArray(criteria) || !criteria.length) {
      throw new Error('AnalystAI.score() requires a non-empty criteria array.');
    }
    const lower = text.toLowerCase();
    const passed = [];
    const failed = [];
    for (const criterion of criteria) {
      const terms = words(criterion, false).filter(w => w.length > 2);
      const hit = terms.some(t => lower.includes(t));
      (hit ? passed : failed).push(criterion);
    }
    const score = Math.round((passed.length / criteria.length) * 100);
    const grade = score >= 80 ? 'Strong' : score >= 60 ? 'Adequate' : score >= 40 ? 'Needs work' : 'Weak';
    return { score, grade, passed, failed };
  }

  /**
   * Summarize a document in plain language.
   *
   * @param {string} text
   * @param {number} [length=3]
   * @returns {{ summary: string, topKeywords: string[], stats: object }}
   */
  summarize(text, length = 3) {
    _need(text, 'summarize');
    const top = scoredSentences(text).slice(0, length).map(s => s.sentence);
    return {
      summary: top.join(' '),
      topKeywords: keywords(text, 5).map(k => k.word),
      stats: readingStats(text),
    };
  }
}

function _need(val, method) {
  if (!val || typeof val !== 'string' || !val.trim()) {
    throw new Error(`AnalystAI.${method}() requires a non-empty string.`);
  }
}

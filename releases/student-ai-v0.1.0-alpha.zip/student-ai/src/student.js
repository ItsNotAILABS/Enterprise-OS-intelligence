/**
 * @medina/student-ai — student.js
 *
 * StudentAI — your embedded AI study companion.
 *
 * Understand long readings, generate quiz questions, make flashcards,
 * get plain-language explanations, and test yourself — all embedded,
 * no subscription, works offline.
 */

import {
  scoredSentences, keywords, findAnswer, sentences,
  words, readingStats, extractSections,
} from './_engine.js';

export class StudentAI {
  // ── Core Methods ───────────────────────────────────────────────────────────

  /**
   * Study a chapter, article, or passage.
   * Returns a structured study guide:
   *  - summary: the key points in plain language
   *  - topics: what this is about
   *  - hardWords: uncommon words worth looking up
   *  - readingTime: how long this takes to read
   *
   * @param {string} text
   * @param {object} [options]
   * @param {number} [options.keyPoints=4] — how many key points to extract
   * @returns {StudyGuide}
   */
  study(text, { keyPoints = 4 } = {}) {
    _need(text, 'study');
    const top = scoredSentences(text).slice(0, keyPoints).map(s => s.sentence);
    const kw = keywords(text, 8).map(k => k.word);
    const stats = readingStats(text);
    const hardWords = _findHardWords(text);
    const sections = extractSections(text).map(s => s.heading).filter(Boolean).slice(0, 6);

    return {
      summary: top.join(' '),
      keyPoints: top,
      topics: kw,
      sections: sections.length ? sections : null,
      hardWords,
      stats,
    };
  }

  /**
   * Generate quiz questions from any text.
   * Questions are formed from the most important sentences.
   * Each question includes a hint so you can check yourself.
   *
   * @param {string} text
   * @param {number} [count=5] — how many questions to generate
   * @returns {Array<{ question: string, hint: string, answer: string }>}
   */
  quiz(text, count = 5) {
    _need(text, 'quiz');
    const topSentences = scoredSentences(text).slice(0, Math.min(count * 2, 20));
    const questions = [];

    for (const { sentence } of topSentences) {
      if (questions.length >= count) break;
      const q = _sentenceToQuestion(sentence);
      if (q) questions.push(q);
    }

    // Pad with keyword-based questions if we don't have enough
    if (questions.length < count) {
      const kw = keywords(text, 10);
      for (const { word } of kw) {
        if (questions.length >= count) break;
        questions.push({
          question: `What role does "${word}" play in this material?`,
          hint: `Look for sentences that mention "${word}"`,
          answer: `Find the passage(s) in the text that explain "${word}" and restate them in your own words.`,
        });
      }
    }

    return questions.slice(0, count);
  }

  /**
   * Make flashcards from a text.
   * Each flashcard has a front (concept/term) and back (definition/explanation).
   *
   * @param {string} text
   * @param {number} [count=8]
   * @returns {Array<{ front: string, back: string }>}
   */
  flashcards(text, count = 8) {
    _need(text, 'flashcards');
    const kw = keywords(text, count * 2);
    const sents = sentences(text);
    const cards = [];

    for (const { word } of kw) {
      if (cards.length >= count) break;
      // Find the sentence that best explains this word
      const relevant = sents
        .filter(s => s.toLowerCase().includes(word))
        .sort((a, b) => b.length - a.length)[0];
      if (relevant) {
        cards.push({ front: word, back: relevant });
      }
    }

    return cards.slice(0, count);
  }

  /**
   * Ask a question about your notes or readings.
   * Returns the most relevant passage with a confidence score.
   *
   * @param {string} question
   * @param {string} notes — your reading or notes to search
   * @returns {{ answer: string|null, confidence: number, found: boolean, encouragement: string }}
   */
  ask(question, notes) {
    _need(question, 'ask (question)');
    _need(notes, 'ask (notes)');
    const { answer, confidence } = findAnswer(question, notes);
    return {
      answer,
      confidence,
      found: !!answer && confidence > 0.1,
      encouragement: confidence > 0.6
        ? 'Good — check the surrounding context to make sure you understand it fully.'
        : confidence > 0.2
        ? "The text touches on this — read around this sentence for the full picture."
        : "This might not be covered in these notes. Try another source or ask your teacher.",
    };
  }

  /**
   * Build a simple outline from a text — great for essays and study notes.
   *
   * @param {string} text
   * @returns {{ title: string, sections: Array<{ heading: string, points: string[] }> }}
   */
  outline(text) {
    _need(text, 'outline');
    const sects = extractSections(text);
    const kw = keywords(text, 3).map(k => k.word).join(', ');

    if (sects.length > 1) {
      return {
        title: `Outline — main topics: ${kw}`,
        sections: sects.slice(0, 8).map(s => ({
          heading: s.heading,
          points: sentences(s.body).slice(0, 3),
        })),
      };
    }

    // No clear sections — build from top sentences
    const top = scoredSentences(text).slice(0, 9);
    const chunked = [];
    for (let i = 0; i < top.length; i += 3) {
      chunked.push({
        heading: `Section ${Math.floor(i / 3) + 1}`,
        points: top.slice(i, i + 3).map(s => s.sentence),
      });
    }
    return { title: `Outline — main topics: ${kw}`, sections: chunked };
  }

  /**
   * Explain a passage in simpler language.
   * Returns a plain-language restatement of the most complex sentences.
   *
   * @param {string} text
   * @returns {{ simplified: string[], original: string, readingLevel: string }}
   */
  explain(text) {
    _need(text, 'explain');
    const stats = readingStats(text);
    const hard = sentences(text)
      .filter(s => s.split(/\s+/).length > 20)
      .slice(0, 4);

    const simplified = hard.map(s => _simplify(s));

    return {
      simplified: simplified.length ? simplified : [text.slice(0, 300)],
      original: text.slice(0, 500),
      readingLevel: stats.avgWordsPerSentence > 20
        ? 'Complex — dense sentences. Break it down paragraph by paragraph.'
        : stats.avgWordsPerSentence > 14
        ? 'Moderate — take it sentence by sentence.'
        : 'Accessible — this is readable. Focus on the key terms.',
    };
  }

  /**
   * Get reading stats for any text.
   * @param {string} text
   * @returns {{ words: number, sentences: number, readingTime: string, avgWordsPerSentence: number }}
   */
  stats(text) {
    _need(text, 'stats');
    return readingStats(text);
  }
}

// ── Internal helpers ──────────────────────────────────────────────────────────

function _need(val, method) {
  if (!val || typeof val !== 'string' || !val.trim()) {
    throw new Error(`StudentAI.${method}() requires a non-empty string.`);
  }
}

/**
 * Turn an important sentence into a fill-in-the-blank or who/what/why question.
 */
function _sentenceToQuestion(sentence) {
  const ws = sentence.split(/\s+/);
  if (ws.length < 6) return null;

  // Pattern: "X is/are/was Y" → "What is X?"
  const isMatch = sentence.match(/^(.{5,40}?)\s+(is|are|was|were|means?|refers? to)\s+(.+)/i);
  if (isMatch) {
    return {
      question: `What ${isMatch[2]} ${isMatch[1].trim()}?`,
      hint: `The answer is in the text — look for the word "${isMatch[1].trim().split(/\s+/).slice(-1)[0]}"`,
      answer: sentence,
    };
  }

  // Pattern: starts with "In [year/context]" → "When / In what context did X happen?"
  const inMatch = sentence.match(/^In\s+(\d{4}|the\s+\w+),?\s+(.+)/i);
  if (inMatch) {
    return {
      question: `What happened in ${inMatch[1]}?`,
      hint: `Look for the sentence starting with "In ${inMatch[1]}"`,
      answer: sentence,
    };
  }

  // Generic: blank out a keyword from the middle of the sentence
  const mid = Math.floor(ws.length / 2);
  const blanked = [...ws];
  blanked[mid] = '______';
  return {
    question: `Fill in the blank: "${blanked.join(' ')}"`,
    hint: `The missing word is a key term from this section.`,
    answer: sentence,
  };
}

/**
 * Very lightweight simplification: extract the core subject-verb-object.
 * This is heuristic, not grammar-parsed — good enough for a study companion.
 */
function _simplify(sentence) {
  // Strip parentheticals
  let s = sentence.replace(/\([^)]*\)/g, '').replace(/,\s*[^,]+,/g, ',').trim();
  // Trim overly long sentences to their first 25 words
  const ws = s.split(/\s+/);
  if (ws.length > 25) s = ws.slice(0, 25).join(' ') + '...';
  return `In simpler terms: ${s}`;
}

function _findHardWords(text) {
  const ws = words(text, false);
  // "Hard" = long words that aren't stop words and appear rarely
  const freq = {};
  for (const w of ws) freq[w] = (freq[w] || 0) + 1;
  return Object.entries(freq)
    .filter(([w, c]) => w.length > 8 && c <= 2)
    .sort((a, b) => b[0].length - a[0].length)
    .slice(0, 8)
    .map(([w]) => w);
}

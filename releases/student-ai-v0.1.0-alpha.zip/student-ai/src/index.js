/**
 * @medina/student-ai
 * Public API.
 */
export { StudentAI } from './student.js';

/**
 * Copyright (c) 2026 Alfredo Medina Hernandez. All Rights Reserved.
 * Medina Tech · Chaos Lab · Dallas, Texas
 * PROPRIETARY AND CONFIDENTIAL. See LICENSE for terms.
 */

/**
 * @medina/student-ai
 * Public API.
 */
export { StudentAI } from './student.js';

/**
 * Copyright (c) 2026 Alfredo Medina Hernandez. All Rights Reserved.
 * Medina Tech · Chaos Lab · Dallas, Texas
 * PROPRIETARY AND CONFIDENTIAL. See LICENSE for terms.
 */

/**
 * @medina/paralegal-ai — risks.js
 *
 * Legal risk pattern database.
 * Used internally by ParalegalAI.analyze() and .risks().
 * Not exported in the public API.
 */

export const RISK_PATTERNS = [
  // Liability
  {
    id: 'UNLIMITED_LIABILITY',
    category: 'Liability',
    severity: 'CRITICAL',
    pattern: /\b(unlimited|no limit|no cap|no maximum|without limit)\b.*?(liabilit|damages|indemnif)/i,
    altPattern: /\b(indemnif|liabilit).*?\b(unlimited|no limit|no cap)\b/i,
    label: 'Unlimited liability exposure',
    detail: 'Contract does not cap liability. Industry standard is 2× contract value for direct damages.',
    recommendation: 'Add a mutual liability cap equal to fees paid in the prior 12 months, excluding gross negligence and willful misconduct.',
  },
  {
    id: 'CONSEQUENTIAL_DAMAGES',
    category: 'Liability',
    severity: 'HIGH',
    pattern: /\b(consequential|indirect|incidental|special|punitive|exemplary)\s+damages\b/i,
    label: 'Consequential damages exposure',
    detail: 'Party may be liable for lost profits, lost data, or business interruption damages.',
    recommendation: 'Mutual waiver of consequential damages with carve-outs only for IP infringement and confidentiality breach.',
  },

  // IP
  {
    id: 'BROAD_IP_ASSIGNMENT',
    category: 'Intellectual Property',
    severity: 'CRITICAL',
    pattern: /\ball\s+(work|works|invention|deliverable|intellectual property|ip|creation)s?\b.*?\bassign/i,
    altPattern: /\bassign.*?\ball\s+(work|works|invention|deliverable|creation)s?\b/i,
    label: 'Overly broad IP assignment',
    detail: 'Assignment of "all works" may include pre-existing tools, frameworks, and reusable components.',
    recommendation: 'Carve out pre-existing IP, general tooling, and IP developed outside the scope of this engagement.',
  },
  {
    id: 'WORK_FOR_HIRE',
    category: 'Intellectual Property',
    severity: 'HIGH',
    pattern: /\bwork[s]?\s+(made\s+)?for\s+hire\b/i,
    label: 'Work-for-hire classification',
    detail: 'Work-for-hire language automatically vests ownership in the client for all deliverables.',
    recommendation: 'Specify which deliverables are work-for-hire vs. licensed. Exclude pre-existing IP explicitly.',
  },

  // Payment
  {
    id: 'LONG_PAYMENT_TERMS',
    category: 'Payment',
    severity: 'MODERATE',
    pattern: /\b(net\s*[-–]?\s*6[0-9]|net\s*[-–]?\s*7\d|net\s*[-–]?\s*8\d|net\s*[-–]?\s*9\d|60\s*days?\s*(after|from)|90\s*days?)\b/i,
    label: 'Extended payment terms (60+ days)',
    detail: 'Payment terms beyond 45 days create significant cash flow risk.',
    recommendation: 'Counter with Net-30 or Net-45. Add 1.5%/month late payment interest after the due date.',
  },
  {
    id: 'NO_LATE_FEE',
    category: 'Payment',
    severity: 'LOW',
    pattern: /\bnet\s*[-–]?\s*\d+\b/i,
    label: 'No late payment interest specified',
    detail: 'Payment terms defined without a late fee clause leaves collections without leverage.',
    recommendation: 'Add: "Invoices unpaid after the due date accrue interest at 1.5% per month."',
    requiresAbsence: /\b(late fee|late payment|interest|penalty|per month|per annum)\b/i,
  },

  // Termination
  {
    id: 'TERMINATION_FOR_CONVENIENCE',
    category: 'Termination',
    severity: 'MODERATE',
    pattern: /\bterminate\b.*?\b(convenience|any reason|no reason|without cause)\b/i,
    altPattern: /\b(any reason|no reason|without cause)\b.*?\bterminate\b/i,
    label: 'Termination for convenience — client only',
    detail: 'Client can exit at will. Check if this right is mutual or one-sided.',
    recommendation: 'Make termination-for-convenience mutual, or add a minimum engagement period before it applies.',
  },
  {
    id: 'SHORT_CURE_PERIOD',
    category: 'Termination',
    severity: 'MODERATE',
    pattern: /\b([1-9]|1[0-4])\s*(?:business\s+)?days?\s+(to\s+cure|cure period|notice)\b/i,
    label: 'Short cure period (< 15 days)',
    detail: 'Cure period under 15 days may not provide sufficient time to remediate a breach.',
    recommendation: 'Standard cure period is 30 days for material breach, with written notice.',
  },

  // Governing law
  {
    id: 'UNFAVORABLE_JURISDICTION',
    category: 'Governing Law',
    severity: 'MODERATE',
    pattern: /\bgoverning\s+law\b.*?\b(delaware|new\s*york|california)\b/i,
    altPattern: /\b(delaware|new\s*york|california)\b.*?\b(govern|jurisdiction|venue)\b/i,
    label: 'Out-of-state governing law / jurisdiction',
    detail: "Disputes resolved under another state's law or courts may add significant legal costs.",
    recommendation: 'Counter with binding arbitration in your state or mutual choice of forum.',
  },

  // Confidentiality
  {
    id: 'BROAD_CONFIDENTIALITY',
    category: 'Confidentiality',
    severity: 'MODERATE',
    pattern: /\ball\s+(information|data|material|communication)s?\b.*?\b(confidential|proprietary)\b/i,
    label: 'Overly broad confidentiality scope',
    detail: '"All information" confidentiality creates compliance risk — nearly everything becomes restricted.',
    recommendation: 'Define confidential information specifically. Add a marking requirement for written disclosures.',
  },

  // Auto-renewal
  {
    id: 'AUTO_RENEWAL',
    category: 'Contract Terms',
    severity: 'LOW',
    pattern: /\b(auto(?:matically)?[-\s]?renew|automatically\s+extend|rolling\s+(term|renewal))\b/i,
    label: 'Auto-renewal clause',
    detail: 'Contract auto-renews without affirmative action. Easy to miss a cancellation window.',
    recommendation: 'Set a calendar reminder 60 days before the renewal date. Consider requesting a longer opt-out window.',
  },
];

/**
 * Run all risk patterns against text.
 * Returns { critical, high, moderate, low, score }
 */
export function detectRisks(text) {
  const found = { CRITICAL: [], HIGH: [], MODERATE: [], LOW: [] };

  for (const risk of RISK_PATTERNS) {
    // Skip if requiresAbsence is set and that pattern IS found
    if (risk.requiresAbsence && risk.requiresAbsence.test(text)) continue;

    const hit = risk.pattern.test(text) || (risk.altPattern && risk.altPattern.test(text));
    if (hit) {
      found[risk.severity].push({
        id: risk.id,
        category: risk.category,
        label: risk.label,
        detail: risk.detail,
        recommendation: risk.recommendation,
      });
    }
  }

  // Risk score: weighted sum capped at 100
  const score = Math.min(
    found.CRITICAL.length * 25 +
    found.HIGH.length * 15 +
    found.MODERATE.length * 7 +
    found.LOW.length * 2,
    100
  );

  return {
    critical: found.CRITICAL,
    high: found.HIGH,
    moderate: found.MODERATE,
    low: found.LOW,
    score,
    totalIssues: found.CRITICAL.length + found.HIGH.length + found.MODERATE.length + found.LOW.length,
  };
}

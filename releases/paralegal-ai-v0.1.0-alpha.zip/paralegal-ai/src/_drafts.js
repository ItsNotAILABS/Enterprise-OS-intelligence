/**
 * @medina/paralegal-ai — _drafts.js
 *
 * Redline and clause draft templates.
 * Not exported in the public API — used by ParalegalAI.draft().
 */

export const DRAFTS = {
  'liability-cap': {
    title: 'Mutual Liability Cap',
    section: 'Limitation of Liability',
    text: `NEITHER PARTY SHALL BE LIABLE TO THE OTHER FOR ANY AMOUNTS IN EXCESS OF THE TOTAL FEES PAID OR PAYABLE BY CLIENT TO [FIRM] DURING THE TWELVE (12) MONTH PERIOD IMMEDIATELY PRECEDING THE CLAIM. THIS LIMITATION APPLIES TO ALL CLAIMS AND CAUSES OF ACTION, WHETHER IN CONTRACT, TORT, STRICT LIABILITY, OR OTHERWISE.`,
    notes: 'Mutual cap. Carve-outs for gross negligence, willful misconduct, and IP infringement recommended. Standard acceptance rate: ~85%.',
  },

  'consequential-waiver': {
    title: 'Mutual Consequential Damages Waiver',
    section: 'Limitation of Liability',
    text: `IN NO EVENT SHALL EITHER PARTY BE LIABLE FOR ANY INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL, PUNITIVE, OR EXEMPLARY DAMAGES, INCLUDING BUT NOT LIMITED TO LOSS OF PROFITS, LOSS OF DATA, OR BUSINESS INTERRUPTION, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGES. EXCEPTIONS: BREACH OF CONFIDENTIALITY OBLIGATIONS AND INTELLECTUAL PROPERTY INFRINGEMENT.`,
    notes: 'Mutual waiver with standard IP/confidentiality carve-outs. Widely accepted in commercial contracts.',
  },

  'ip-carveout': {
    title: 'Pre-Existing IP Carve-Out',
    section: 'Intellectual Property',
    text: `Notwithstanding any other provision of this Agreement, the assignment of deliverables to Client shall expressly exclude: (i) any tools, frameworks, libraries, methods, or know-how owned by [FIRM] prior to the Effective Date of this Agreement; (ii) any general-purpose tools, utilities, or components developed by [FIRM] during the term of this Agreement that are not specific to Client's business or deliverables; and (iii) any improvements or modifications to the foregoing. [FIRM] grants Client a non-exclusive, royalty-free license to use such pre-existing materials solely to the extent incorporated in the deliverables.`,
    notes: 'Protects your internal IP library. Standard carve-out. Acceptance rate: ~81%.',
  },

  'late-payment': {
    title: 'Late Payment Interest Clause',
    section: 'Payment Terms',
    text: `Invoices not paid within the agreed payment period shall accrue interest at the rate of one and one-half percent (1.5%) per month (18% per annum), or the maximum rate permitted by applicable law, whichever is lower, from the due date until paid in full. [FIRM] reserves the right to suspend services for invoices more than thirty (30) days past due upon written notice.`,
    notes: 'Standard commercial late payment provision. Include with any Net-30 or longer payment terms.',
  },

  'mutual-termination': {
    title: 'Mutual Termination for Convenience',
    section: 'Termination',
    text: `Either party may terminate this Agreement for any reason upon thirty (30) days' prior written notice to the other party. Upon termination for convenience by Client, Client shall pay [FIRM] for all work performed through the effective date of termination, plus any non-cancellable commitments made by [FIRM] on Client's behalf. Upon termination for convenience by [FIRM], [FIRM] shall complete any deliverables that are substantially complete and transition work product to Client in an organized manner.`,
    notes: 'Mutual right, 30-day notice, protects compensation for work in progress.',
  },

  'arbitration': {
    title: 'Binding Arbitration Clause',
    section: 'Dispute Resolution',
    text: `Any dispute, controversy, or claim arising out of or relating to this Agreement, or the breach, termination, or validity thereof, shall be settled by binding arbitration administered by JAMS pursuant to its Comprehensive Arbitration Rules and Procedures. Arbitration shall be conducted by a single arbitrator in [CITY, STATE]. Judgment on the award rendered may be entered in any court having jurisdiction. The prevailing party shall be entitled to recover reasonable attorneys' fees and costs.`,
    notes: 'Replace [CITY, STATE] with your jurisdiction. Eliminates expensive out-of-state litigation.',
  },

  'confidentiality-definition': {
    title: 'Narrowed Confidentiality Definition',
    section: 'Confidentiality',
    text: `"Confidential Information" means information disclosed by one party (the "Disclosing Party") to the other (the "Receiving Party") that is designated in writing as confidential at the time of disclosure, or that a reasonable person would understand to be confidential given the nature of the information and the circumstances of disclosure. Confidential Information does not include information that: (i) is or becomes publicly available without breach of this Agreement; (ii) was known to the Receiving Party before disclosure; (iii) is independently developed by the Receiving Party without use of the Confidential Information; or (iv) is required to be disclosed by law or court order.`,
    notes: 'Standard four-exception confidentiality definition. Replaces overbroad "all information" language.',
  },
};

/**
 * Get a draft by key. Returns the draft object or null.
 */
export function getDraft(key) {
  // Flexible lookup: exact key, or closest match
  if (DRAFTS[key]) return DRAFTS[key];
  const lower = key.toLowerCase().replace(/\s+/g, '-');
  const match = Object.keys(DRAFTS).find(k => k === lower || lower.includes(k) || k.includes(lower));
  return match ? DRAFTS[match] : null;
}

/**
 * List all available draft types.
 */
export function listDraftTypes() {
  return Object.entries(DRAFTS).map(([key, d]) => ({
    key,
    title: d.title,
    section: d.section,
  }));
}

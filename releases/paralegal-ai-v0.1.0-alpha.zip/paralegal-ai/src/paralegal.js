/**
 * @medina/paralegal-ai — paralegal.js
 *
 * ParalegalAI — your embedded AI legal assistant.
 *
 * Analyze contracts, surface risk clauses, get plain-language answers,
 * draft standard redlines, and compare documents — all without
 * sending your documents to any server.
 */

import { scoredSentences, keywords, findAnswer, similarity, extractDates, readingStats, extractSections } from './_engine.js';
import { detectRisks } from './_risks.js';
import { getDraft, listDraftTypes } from './_drafts.js';

export class ParalegalAI {
  // ── Main Methods ───────────────────────────────────────────────────────────

  /**
   * Analyze a contract or legal document for risk.
   *
   * Returns a full risk report with:
   *  - risk score (0–100, lower is better)
   *  - critical, high, moderate, and low issues with recommendations
   *  - key dates found in the document
   *  - top subject matter keywords
   *  - reading stats (page count estimate, reading time)
   *
   * @param {string} text — the full contract text
   * @returns {AnalysisResult}
   */
  analyze(text) {
    _need(text, 'analyze');
    const risks = detectRisks(text);
    const kw = keywords(text, 8).map(k => k.word);
    const dates = extractDates(text);
    const stats = readingStats(text);
    const sections = extractSections(text).map(s => s.heading).filter(Boolean).slice(0, 12);

    return {
      riskScore: risks.score,
      riskLevel: risks.score >= 50 ? 'HIGH' : risks.score >= 25 ? 'MODERATE' : 'LOW',
      totalIssues: risks.totalIssues,
      critical: risks.critical,
      high: risks.high,
      moderate: risks.moderate,
      low: risks.low,
      keyDates: dates,
      topKeywords: kw,
      sections,
      stats,
      summary: _riskSummary(risks),
    };
  }

  /**
   * Scan a document for risk issues only, without the full analysis.
   * Faster for a quick check.
   *
   * @param {string} text
   * @returns {{ issues: Array, score: number, riskLevel: string }}
   */
  risks(text) {
    _need(text, 'risks');
    const r = detectRisks(text);
    const allIssues = [...r.critical, ...r.high, ...r.moderate, ...r.low];
    return {
      issues: allIssues,
      score: r.score,
      riskLevel: r.score >= 50 ? 'HIGH' : r.score >= 25 ? 'MODERATE' : 'LOW',
    };
  }

  /**
   * Ask a plain-language question about a contract or legal document.
   * Returns the most relevant passage with a confidence score.
   *
   * @param {string} question
   * @param {string} context  — the document text
   * @returns {{ answer: string|null, confidence: number, found: boolean, tip: string }}
   */
  ask(question, context) {
    _need(question, 'ask (question)');
    _need(context, 'ask (context)');
    const { answer, confidence } = findAnswer(question, context);
    return {
      answer,
      confidence,
      found: !!answer && confidence > 0.1,
      tip: confidence < 0.3
        ? 'Low confidence — the document may not directly address this question.'
        : confidence < 0.6
        ? 'Moderate confidence — review the surrounding context for full meaning.'
        : 'Good match found.',
    };
  }

  /**
   * Get a plain-language summary of a contract.
   * Returns the most important passages, key terms, and dates.
   *
   * @param {string} text
   * @param {number} [length=4] — number of key passages to include
   * @returns {{ summary: string, keyTerms: string[], keyDates: string[], stats: object }}
   */
  summarize(text, length = 4) {
    _need(text, 'summarize');
    const top = scoredSentences(text).slice(0, length).map(s => s.sentence);
    const keyTerms = keywords(text, 6).map(k => k.word);
    const keyDates = extractDates(text);
    const stats = readingStats(text);
    return {
      summary: top.join(' '),
      keyTerms,
      keyDates,
      stats,
    };
  }

  /**
   * Compare two contracts or document versions.
   * Tells you how similar they are and what themes are shared or different.
   *
   * @param {string} docA
   * @param {string} docB
   * @returns {{ similarity: string, score: number, sharedThemes: string[], uniqueToA: string[], uniqueToB: string[] }}
   */
  compare(docA, docB) {
    _need(docA, 'compare (docA)');
    _need(docB, 'compare (docB)');
    const { score, shared } = similarity(docA, docB);

    const kwA = keywords(docA, 12).map(k => k.word);
    const kwB = keywords(docB, 12).map(k => k.word);
    const setB = new Set(kwB);
    const setA = new Set(kwA);

    return {
      similarity: `${Math.round(score * 100)}%`,
      score,
      sharedThemes: shared,
      uniqueToA: kwA.filter(w => !setB.has(w)).slice(0, 6),
      uniqueToB: kwB.filter(w => !setA.has(w)).slice(0, 6),
    };
  }

  /**
   * Get a ready-to-use redline draft for a specific clause type.
   *
   * Available types:
   *   'liability-cap', 'consequential-waiver', 'ip-carveout',
   *   'late-payment', 'mutual-termination', 'arbitration',
   *   'confidentiality-definition'
   *
   * @param {string} type — the clause type you want to draft
   * @returns {{ title: string, section: string, text: string, notes: string }|null}
   */
  draft(type) {
    _need(type, 'draft');
    const result = getDraft(type);
    if (!result) {
      return {
        error: `No draft found for "${type}".`,
        available: listDraftTypes().map(d => d.key),
      };
    }
    return result;
  }

  /**
   * List all available draft clause types.
   * Use these keys with .draft(type).
   *
   * @returns {Array<{ key: string, title: string, section: string }>}
   */
  availableDrafts() {
    return listDraftTypes();
  }

  /**
   * Extract all dates, deadlines, and time references from a contract.
   *
   * @param {string} text
   * @returns {string[]}
   */
  timeline(text) {
    _need(text, 'timeline');
    return extractDates(text);
  }
}

// ── Internal helpers ─────────────────────────────────────────────────────────

function _need(val, method) {
  if (!val || typeof val !== 'string' || !val.trim()) {
    throw new Error(`ParalegalAI.${method}() requires a non-empty string.`);
  }
}

function _riskSummary({ critical, high, moderate, low, score }) {
  const parts = [];
  if (critical.length) parts.push(`${critical.length} critical issue${critical.length > 1 ? 's' : ''} require immediate attention`);
  if (high.length) parts.push(`${high.length} high-severity clause${high.length > 1 ? 's' : ''} should be negotiated`);
  if (moderate.length) parts.push(`${moderate.length} moderate concern${moderate.length > 1 ? 's' : ''} worth addressing`);
  if (low.length) parts.push(`${low.length} low-priority item${low.length > 1 ? 's' : ''} to be aware of`);
  if (!parts.length) return 'No significant risk patterns detected. Standard review still recommended.';
  return parts.join('; ') + `. Overall risk score: ${score}/100.`;
}

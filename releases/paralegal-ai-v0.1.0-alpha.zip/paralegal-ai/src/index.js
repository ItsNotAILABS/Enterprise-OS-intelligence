/**
 * @medina/paralegal-ai
 * Public API — this is all users need to import.
 */
export { ParalegalAI } from './paralegal.js';

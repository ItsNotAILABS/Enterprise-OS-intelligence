/**
 * Copyright (c) 2026 Alfredo Medina Hernandez. All Rights Reserved.
 * Medina Tech · Chaos Lab · Dallas, Texas
 * PROPRIETARY AND CONFIDENTIAL. See LICENSE for terms.
 */

/**
 * @medina/paralegal-ai
 * Public API — this is all users need to import.
 */
export { ParalegalAI } from './paralegal.js';

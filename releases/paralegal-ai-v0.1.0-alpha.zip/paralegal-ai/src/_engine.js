/**
 * Copyright (c) 2026 Alfredo Medina Hernandez. All Rights Reserved.
 * Medina Tech · Chaos Lab · Dallas, Texas
 * PROPRIETARY AND CONFIDENTIAL. See LICENSE for terms.
 */

/**
 * Internal reasoning engine — not exported in public API.
 *
 * Provides sentence scoring, keyword extraction, similarity matching,
 * and question answering over arbitrary text.
 *
 * Used internally by all three AI SDKs.
 */

const STOP = new Set([
  'a','an','the','and','or','but','in','on','at','to','for','of','with','by',
  'from','is','are','was','were','be','been','have','has','had','do','does',
  'did','will','would','could','should','may','might','this','that','these',
  'those','it','its','we','our','you','your','they','their','he','she','his',
  'her','i','my','me','us','him','not','no','so','as','if','then','than',
  'also','just','more','about','up','out','into','what','which','who','when',
  'where','how','all','some','any','each','both','very','here','there','can',
  'get','got','see','use','one','two','three','four','five','six','seven',
]);

// ── Tokenizers ──────────────────────────────────────────────────────────────

export function sentences(text) {
  return text
    .replace(/([.!?;])\s+([A-Z])/g, '$1\n$2')
    .split('\n')
    .map(s => s.trim())
    .filter(s => s.length > 15 && /[a-zA-Z]/.test(s));
}

export function words(text, noStop = true) {
  const raw = text.toLowerCase().replace(/[^a-z0-9\s]/g, ' ').split(/\s+/).filter(w => w.length > 1);
  return noStop ? raw.filter(w => !STOP.has(w)) : raw;
}

// ── Term frequency ──────────────────────────────────────────────────────────

function tf(wordList) {
  const freq = {};
  for (const w of wordList) freq[w] = (freq[w] || 0) + 1;
  return freq;
}

// ── Cosine similarity ───────────────────────────────────────────────────────

function cosine(freqA, freqB) {
  const keys = new Set([...Object.keys(freqA), ...Object.keys(freqB)]);
  let dot = 0, nA = 0, nB = 0;
  for (const k of keys) {
    const a = freqA[k] || 0, b = freqB[k] || 0;
    dot += a * b; nA += a * a; nB += b * b;
  }
  return nA && nB ? dot / Math.sqrt(nA * nB) : 0;
}

// ── Sentence scoring ────────────────────────────────────────────────────────

export function scoredSentences(text) {
  const sents = sentences(text);
  if (!sents.length) return [];
  const docFreq = tf(words(text));
  const maxFreq = Math.max(...Object.values(docFreq), 1);
  return sents.map(s => {
    const ws = words(s);
    const score = ws.length
      ? ws.reduce((sum, w) => sum + (docFreq[w] || 0), 0) / ws.length / maxFreq
      : 0;
    return { sentence: s, score };
  }).sort((a, b) => b.score - a.score);
}

// ── Keywords ────────────────────────────────────────────────────────────────

export function keywords(text, n = 8) {
  return Object.entries(tf(words(text)))
    .filter(([w]) => w.length > 3)
    .sort((a, b) => b[1] - a[1])
    .slice(0, n)
    .map(([word, count]) => ({ word, count }));
}

// ── Q&A: find the sentence in context most relevant to a question ───────────

export function findAnswer(question, context) {
  const qFreq = tf(words(question));
  const ranked = sentences(context).map(s => ({
    sentence: s,
    score: cosine(qFreq, tf(words(s))),
  })).sort((a, b) => b.score - a.score);

  if (!ranked.length || ranked[0].score === 0) return { answer: null, confidence: 0 };
  return {
    answer: ranked[0].sentence,
    confidence: parseFloat(Math.min(ranked[0].score * 2, 1).toFixed(2)),
  };
}

// ── Similarity between two full texts ───────────────────────────────────────

export function similarity(textA, textB) {
  const freqA = tf(words(textA));
  const freqB = tf(words(textB));
  const score = cosine(freqA, freqB);
  const shared = Object.keys(freqA).filter(w => freqB[w] && w.length > 3);
  return { score: parseFloat(score.toFixed(3)), shared: shared.slice(0, 10) };
}

// ── Extract numbers / metrics mentioned in text ─────────────────────────────

export function extractNumbers(text) {
  const matches = text.match(/\$[\d,]+(?:\.\d+)?[MBKmk]?|\b\d+(?:,\d{3})*(?:\.\d+)?%?(?:\s*(?:million|billion|thousand|M|B|K))?\b/g) || [];
  return [...new Set(matches)].slice(0, 20);
}

// ── Extract date-like strings ────────────────────────────────────────────────

export function extractDates(text) {
  const patterns = [
    /\b(?:Jan|Feb|Mar|Apr|May|Jun|Jul|Aug|Sep|Oct|Nov|Dec)[a-z]*\.?\s+\d{1,2},?\s+\d{4}\b/gi,
    /\b\d{1,2}[\/\-]\d{1,2}[\/\-]\d{2,4}\b/g,
    /\b(?:Q[1-4]|quarter\s+[1-4])\s+\d{4}\b/gi,
    /\b\d{4}\b/g,
  ];
  const found = [];
  for (const p of patterns) {
    const m = text.match(p) || [];
    found.push(...m);
  }
  return [...new Set(found)].slice(0, 15);
}

// ── Split text into rough sections by heading patterns ──────────────────────

export function extractSections(text) {
  const lines = text.split('\n').map(l => l.trim()).filter(Boolean);
  const sections = [];
  let current = null;
  for (const line of lines) {
    const isHeading = /^#{1,3}\s/.test(line) ||
      /^§\d/.test(line) ||
      /^[A-Z][A-Z\s]{4,}$/.test(line) ||
      /^\d+\.\s+[A-Z]/.test(line);
    if (isHeading) {
      if (current) sections.push(current);
      current = { heading: line.replace(/^#{1,3}\s/, ''), body: '' };
    } else if (current) {
      current.body += ' ' + line;
    } else {
      current = { heading: 'Introduction', body: line };
    }
  }
  if (current) sections.push(current);
  return sections.map(s => ({ ...s, body: s.body.trim() }));
}

// ── Reading stats ────────────────────────────────────────────────────────────

export function readingStats(text) {
  const wordCount = text.split(/\s+/).filter(Boolean).length;
  const sentCount = sentences(text).length || 1;
  const avgLen = wordCount / sentCount;
  return {
    words: wordCount,
    sentences: sentCount,
    avgWordsPerSentence: parseFloat(avgLen.toFixed(1)),
    readingTime: wordCount < 200 ? '< 1 min' : `~${Math.ceil(wordCount / 200)} min`,
  };
}
